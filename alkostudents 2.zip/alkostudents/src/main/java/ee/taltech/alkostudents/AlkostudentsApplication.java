package ee.taltech.alkostudents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlkostudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlkostudentsApplication.class, args);
	}

}
